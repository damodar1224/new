﻿namespace BethanysPieShopHRM.Shared
{
    public enum Gender
    {
        Male,
        Female,
        Other
    }
}
